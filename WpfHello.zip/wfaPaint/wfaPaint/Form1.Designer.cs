﻿namespace wfaPaint
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.buiImageLoadFromfile = new System.Windows.Forms.Button();
            this.buiImageSaveToFile = new System.Windows.Forms.Button();
            this.guiImageClear = new System.Windows.Forms.Button();
            this.modeRectangle = new System.Windows.Forms.Button();
            this.modeEllipse = new System.Windows.Forms.Button();
            this.modeLine = new System.Windows.Forms.Button();
            this.modePencil = new System.Windows.Forms.Button();
            this.trPenWidth = new System.Windows.Forms.TrackBar();
            this.paColor5 = new System.Windows.Forms.Panel();
            this.paColor4 = new System.Windows.Forms.Panel();
            this.paColor3 = new System.Windows.Forms.Panel();
            this.paColor2 = new System.Windows.Forms.Panel();
            this.paColor1 = new System.Windows.Forms.Panel();
            this.pxImage = new System.Windows.Forms.PictureBox();
            this.buiImageCopyToClipboard = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trPenWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pxImage)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.buiImageCopyToClipboard);
            this.panel1.Controls.Add(this.buiImageLoadFromfile);
            this.panel1.Controls.Add(this.buiImageSaveToFile);
            this.panel1.Controls.Add(this.guiImageClear);
            this.panel1.Controls.Add(this.modeRectangle);
            this.panel1.Controls.Add(this.modeEllipse);
            this.panel1.Controls.Add(this.modeLine);
            this.panel1.Controls.Add(this.modePencil);
            this.panel1.Controls.Add(this.trPenWidth);
            this.panel1.Controls.Add(this.paColor5);
            this.panel1.Controls.Add(this.paColor4);
            this.panel1.Controls.Add(this.paColor3);
            this.panel1.Controls.Add(this.paColor2);
            this.panel1.Controls.Add(this.paColor1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 450);
            this.panel1.TabIndex = 0;
            // 
            // buiImageLoadFromfile
            // 
            this.buiImageLoadFromfile.Location = new System.Drawing.Point(12, 390);
            this.buiImageLoadFromfile.Name = "buiImageLoadFromfile";
            this.buiImageLoadFromfile.Size = new System.Drawing.Size(181, 23);
            this.buiImageLoadFromfile.TabIndex = 11;
            this.buiImageLoadFromfile.Text = "Load from file";
            this.buiImageLoadFromfile.UseVisualStyleBackColor = true;
            // 
            // buiImageSaveToFile
            // 
            this.buiImageSaveToFile.Location = new System.Drawing.Point(12, 361);
            this.buiImageSaveToFile.Name = "buiImageSaveToFile";
            this.buiImageSaveToFile.Size = new System.Drawing.Size(181, 23);
            this.buiImageSaveToFile.TabIndex = 10;
            this.buiImageSaveToFile.Text = "Save to file";
            this.buiImageSaveToFile.UseVisualStyleBackColor = true;
            // 
            // guiImageClear
            // 
            this.guiImageClear.Location = new System.Drawing.Point(12, 332);
            this.guiImageClear.Name = "guiImageClear";
            this.guiImageClear.Size = new System.Drawing.Size(181, 23);
            this.guiImageClear.TabIndex = 9;
            this.guiImageClear.Text = "Clear Image";
            this.guiImageClear.UseVisualStyleBackColor = true;
            // 
            // modeRectangle
            // 
            this.modeRectangle.Location = new System.Drawing.Point(12, 193);
            this.modeRectangle.Name = "modeRectangle";
            this.modeRectangle.Size = new System.Drawing.Size(181, 23);
            this.modeRectangle.TabIndex = 8;
            this.modeRectangle.Text = "Recktangle";
            this.modeRectangle.UseVisualStyleBackColor = true;
            // 
            // modeEllipse
            // 
            this.modeEllipse.Location = new System.Drawing.Point(12, 164);
            this.modeEllipse.Name = "modeEllipse";
            this.modeEllipse.Size = new System.Drawing.Size(181, 23);
            this.modeEllipse.TabIndex = 7;
            this.modeEllipse.Text = "Elipse";
            this.modeEllipse.UseVisualStyleBackColor = true;
            // 
            // modeLine
            // 
            this.modeLine.Location = new System.Drawing.Point(12, 135);
            this.modeLine.Name = "modeLine";
            this.modeLine.Size = new System.Drawing.Size(181, 23);
            this.modeLine.TabIndex = 6;
            this.modeLine.Text = "Line";
            this.modeLine.UseVisualStyleBackColor = true;
            this.modeLine.Click += new System.EventHandler(this.button2_Click);
            // 
            // modePencil
            // 
            this.modePencil.Location = new System.Drawing.Point(12, 106);
            this.modePencil.Name = "modePencil";
            this.modePencil.Size = new System.Drawing.Size(181, 23);
            this.modePencil.TabIndex = 2;
            this.modePencil.Text = "Pencil";
            this.modePencil.UseVisualStyleBackColor = true;
            // 
            // trPenWidth
            // 
            this.trPenWidth.Location = new System.Drawing.Point(4, 58);
            this.trPenWidth.Name = "trPenWidth";
            this.trPenWidth.Size = new System.Drawing.Size(190, 56);
            this.trPenWidth.TabIndex = 5;
            // 
            // paColor5
            // 
            this.paColor5.BackColor = System.Drawing.Color.Black;
            this.paColor5.Location = new System.Drawing.Point(137, 13);
            this.paColor5.Name = "paColor5";
            this.paColor5.Size = new System.Drawing.Size(25, 25);
            this.paColor5.TabIndex = 4;
            // 
            // paColor4
            // 
            this.paColor4.BackColor = System.Drawing.Color.Yellow;
            this.paColor4.Location = new System.Drawing.Point(106, 13);
            this.paColor4.Name = "paColor4";
            this.paColor4.Size = new System.Drawing.Size(25, 25);
            this.paColor4.TabIndex = 3;
            // 
            // paColor3
            // 
            this.paColor3.BackColor = System.Drawing.Color.Blue;
            this.paColor3.Location = new System.Drawing.Point(75, 13);
            this.paColor3.Name = "paColor3";
            this.paColor3.Size = new System.Drawing.Size(25, 25);
            this.paColor3.TabIndex = 2;
            // 
            // paColor2
            // 
            this.paColor2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.paColor2.Location = new System.Drawing.Point(44, 13);
            this.paColor2.Name = "paColor2";
            this.paColor2.Size = new System.Drawing.Size(25, 25);
            this.paColor2.TabIndex = 1;
            // 
            // paColor1
            // 
            this.paColor1.BackColor = System.Drawing.Color.Red;
            this.paColor1.Location = new System.Drawing.Point(13, 13);
            this.paColor1.Name = "paColor1";
            this.paColor1.Size = new System.Drawing.Size(25, 25);
            this.paColor1.TabIndex = 0;
            // 
            // pxImage
            // 
            this.pxImage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pxImage.Location = new System.Drawing.Point(200, 0);
            this.pxImage.Name = "pxImage";
            this.pxImage.Size = new System.Drawing.Size(600, 450);
            this.pxImage.TabIndex = 1;
            this.pxImage.TabStop = false;
            // 
            // button1
            // 
            this.buiImageCopyToClipboard.Location = new System.Drawing.Point(12, 419);
            this.buiImageCopyToClipboard.Name = "button1";
            this.buiImageCopyToClipboard.Size = new System.Drawing.Size(181, 23);
            this.buiImageCopyToClipboard.TabIndex = 12;
            this.buiImageCopyToClipboard.Text = "Load from file";
            this.buiImageCopyToClipboard.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pxImage);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "wfaPaint";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trPenWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pxImage)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel paColor5;
        private System.Windows.Forms.Panel paColor4;
        private System.Windows.Forms.Panel paColor3;
        private System.Windows.Forms.Panel paColor2;
        private System.Windows.Forms.Panel paColor1;
        private System.Windows.Forms.PictureBox pxImage;
        private System.Windows.Forms.Button modeRectangle;
        private System.Windows.Forms.Button modeEllipse;
        private System.Windows.Forms.Button modeLine;
        private System.Windows.Forms.Button modePencil;
        private System.Windows.Forms.TrackBar trPenWidth;
        private System.Windows.Forms.Button buiImageLoadFromfile;
        private System.Windows.Forms.Button buiImageSaveToFile;
        private System.Windows.Forms.Button guiImageClear;
        private System.Windows.Forms.Button buiImageCopyToClipboard;
    }
}

